package com.tns.collegeservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CollegeserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
