export interface Employee
{
    eid:number;
    ename:String;
    desig:String;
}