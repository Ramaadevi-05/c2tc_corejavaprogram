package com.tnsif.dayfive.multilevelinheritance.vehicle;

public class Maruti800 extends Maruti {

	public Maruti800() {
		System.out.println("Maruti Model: 800");
	}

	public void speed() {
		System.out.println("Max: 80Kmph");
	}

}