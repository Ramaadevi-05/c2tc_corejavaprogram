//Program to demonstrate method overriding - Runtime Polymorphism
package com.tnsif.dayseven.overriding;

//Superclass
public class RBI {
	public float getRateOfInterest() {
		return 6.7f;
	}

}
