package com.tnsif.spring_IOC_DI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringIocDiApplicationTests {

	@Test
	void contextLoads() {
	}

}
