package com.tnsif.SpringBoot.RestFul_API;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestFulApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestFulApiApplication.class, args);
	}

}
