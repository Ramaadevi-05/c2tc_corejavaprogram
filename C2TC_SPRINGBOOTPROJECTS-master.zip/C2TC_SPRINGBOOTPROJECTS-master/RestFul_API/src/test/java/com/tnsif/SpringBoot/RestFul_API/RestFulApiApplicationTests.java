package com.tnsif.SpringBoot.RestFul_API;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestFulApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
