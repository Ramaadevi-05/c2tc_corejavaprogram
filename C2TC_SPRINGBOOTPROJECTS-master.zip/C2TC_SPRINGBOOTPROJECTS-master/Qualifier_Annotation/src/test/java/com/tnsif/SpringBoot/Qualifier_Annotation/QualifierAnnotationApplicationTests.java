package com.tnsif.SpringBoot.Qualifier_Annotation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QualifierAnnotationApplicationTests {

	@Test
	void contextLoads() {
	}

}
