package com.tnsif.SpringBoot.Qualifier_Annotation;

public interface Ordering {
	
	void order();

}
