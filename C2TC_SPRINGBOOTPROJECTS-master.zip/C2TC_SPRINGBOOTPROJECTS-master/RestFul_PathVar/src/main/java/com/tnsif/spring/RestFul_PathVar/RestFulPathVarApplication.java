package com.tnsif.spring.RestFul_PathVar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestFulPathVarApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestFulPathVarApplication.class, args);
	}

}
