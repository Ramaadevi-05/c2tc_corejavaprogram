package com.tnsif.spring.RestFul_PathVar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestFulPathVarApplicationTests {

	@Test
	void contextLoads() {
	}

}
