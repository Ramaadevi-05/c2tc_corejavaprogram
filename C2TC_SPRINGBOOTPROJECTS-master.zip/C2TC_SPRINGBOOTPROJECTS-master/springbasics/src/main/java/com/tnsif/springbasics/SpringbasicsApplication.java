package com.tnsif.springbasics;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbasicsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbasicsApplication.class, args);
		System.out.println("Heloooo Dearrrr Coderrrrssss");
	}

}
