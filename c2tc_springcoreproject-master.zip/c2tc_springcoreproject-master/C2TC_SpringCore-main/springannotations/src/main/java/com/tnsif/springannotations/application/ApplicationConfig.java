package com.tnsif.springannotations.application;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan({"com.tnsif.springannotations.application"})

public class ApplicationConfig {

}
