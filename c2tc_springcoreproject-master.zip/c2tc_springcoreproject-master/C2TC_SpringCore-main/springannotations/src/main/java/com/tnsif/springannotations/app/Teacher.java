package com.tnsif.springannotations.app;

public interface Teacher {
	
	public String getTeacherInfo();

}
