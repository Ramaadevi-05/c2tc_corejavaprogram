package com.tnsif.springcoreIOC;

public interface Phone {
	
	void calling();
	void internet();

}
